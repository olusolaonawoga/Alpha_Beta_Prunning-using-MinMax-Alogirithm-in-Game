import board as b
class game():
	def __init__(self,p1,p2):
		self.p1=p1
		self.p2=p2

	def score(self):

	def gameend(self);

	def report(self):
